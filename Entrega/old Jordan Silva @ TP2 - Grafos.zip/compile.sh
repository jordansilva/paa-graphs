#!/bin/bash
make
rm -R puzzle/obj