#!/bin/bash
puzzle/bin/puzzle "$1"